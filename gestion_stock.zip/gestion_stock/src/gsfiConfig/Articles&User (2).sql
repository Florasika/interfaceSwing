 

/*CREATION DE LA BASE DE DONNEES*/

CREATE DATABASE stock;


DROP TABLE if exists articles;

/*CREATION DE LA TABLE ARTICLES*/

CREATE TABLE articles(
    code integer PRIMARY KEY AUTO_INCREMENT,
    quantite integer,
    limite integer,
    prix_unit double,
    date_creation date);

DROP TABLE if exists utilisateur;


/*CREATION DE LA TABLE UTILISATEUR*/


CREATE TABLE utilisateur(
    id integer PRIMARY KEY AUTO_INCREMENT,
    nom varchar(50),
    pass varchar(50));