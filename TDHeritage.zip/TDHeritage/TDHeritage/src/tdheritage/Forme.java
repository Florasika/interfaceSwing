/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tdheritage;

/**
 *
 * @author HP
 */
public abstract class Forme {

    
    public String afficher(){
        return null;
    }
    
    public abstract int perimetre();
    
    public abstract int aire();
   
    
}
