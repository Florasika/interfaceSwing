/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package intefaceswing1;

/**
 *
 * @author Israel
 */
public class NumerateurInvalidException extends Exception{

    public NumerateurInvalidException(String message) {
        super(message);
    }
    
}
